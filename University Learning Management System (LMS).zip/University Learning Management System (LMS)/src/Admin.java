import javax.swing.*;
import java.util.Arrays;

public class Admin {
    Admin(String pword){
        String pw = pword;

    }


}
