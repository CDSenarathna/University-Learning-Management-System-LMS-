import java.sql.*;
public class Demo {

    public static void main(String[] args) {

        Logging log1 = new Logging();
    }

    public static void dbConnect() {

        }
    }
//String username = User.getUserin(); Oka dala log una user ge Id eka gnna hama ekktma

