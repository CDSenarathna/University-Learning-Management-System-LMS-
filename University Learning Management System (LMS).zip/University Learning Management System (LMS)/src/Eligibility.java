import javax.swing.*;

public class Eligibility {
    private JComboBox comboBox1;
    private JTable table1;
}
