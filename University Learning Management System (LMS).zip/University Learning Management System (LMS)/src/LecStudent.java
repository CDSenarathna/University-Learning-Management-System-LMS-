public class LecStudent {
}
