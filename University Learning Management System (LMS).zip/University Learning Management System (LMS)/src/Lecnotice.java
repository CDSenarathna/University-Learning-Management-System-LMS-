public class Lecnotice {
}
