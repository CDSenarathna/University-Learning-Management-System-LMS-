public class Users {
    public String userid;
    public String fname;
    public String lname;
    public String address;
    public String email;
    public String birthday;
    public String contactnumber;
    public String usertype;
    public String department;
    public String adminid;
    public String password;
    public String confirmpassword;

}
