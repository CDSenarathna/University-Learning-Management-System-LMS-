import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class signup {
    private JPanel signup;
    private JButton calculateButton;
    private JButton clearButton;
    private JTextField textField1;
    private JTextField textField2;
public signup() {
    calculateButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

        }
    });
}
}
